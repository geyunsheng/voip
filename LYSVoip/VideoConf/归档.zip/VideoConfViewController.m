//
//  videoChatrommViewController.m
//  CCPVoipDemo
//
//  Created by wang ming on 13-10-24.
//  Copyright (c) 2013年 hisun. All rights reserved.
//

#import "VideoConfViewController.h"

@interface VideoConfViewController ()

@end

@implementation VideoConfViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc]
                                   initWithCustomView:[CommonTools navigationBackItemBtnInitWithTarget:self action:@selector(back)]];
    self.navigationItem.leftBarButtonItem = backButton;
    [backButton release];
    
    UIImageView * img1;
    img1 = [[UIImageView alloc] init];
    img1.frame = CGRectMake(9.5f, 90, 301, 250);
    img1.image = nil;
    img1.tag = 1001;
    [self.view addSubview:img1];
    [img1 release];
    
    self.title  = @"视频会议";
    self.view.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255. alpha:1];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
