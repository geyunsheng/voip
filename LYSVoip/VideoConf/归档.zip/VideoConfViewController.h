//
//  videoChatrommViewController.h
//  CCPVoipDemo
//
//  Created by wang ming on 13-10-24.
//  Copyright (c) 2013年 hisun. All rights reserved.
//

#import "UIBaseViewController.h"

@interface VideoConfViewController : UIBaseViewController

@end
