//
//  videoChatroomIntroduction.m
//  CCPVoipDemo
//
//  Created by wang ming on 13-10-23.
//  Copyright (c) 2013年 hisun. All rights reserved.
//

#import "VideoConfIntroduction.h"
#import "UISelectViewController.h"

@interface VideoConfIntroduction ()

@end

@implementation VideoConfIntroduction
-(void)dealloc
{

    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc]
                                   initWithCustomView:[CommonTools navigationBackItemBtnInitWithTarget:self action:@selector(back)]];
    self.navigationItem.leftBarButtonItem = backButton;
    [backButton release];
    
    UIImageView * img1;
    img1 = [[UIImageView alloc] init];
    img1.frame = CGRectMake(9.5f, 90, 301, 250);
    img1.image = nil;
    img1.tag = 1001;
    [self.view addSubview:img1];
    [img1 release];
    
    self.title  = @"视频会议";
    self.view.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255. alpha:1];
    
    UILabel* lab1;
    lab1 = [[UILabel alloc] init];
    lab1.frame = CGRectMake(20, 300, 280, 60);
    lab1.text = @"能力介绍：云通讯视频会议能力提供多路交叉视频及一对多视频（可手动切换或自动切到发言方）并支持电话用户语音加入，同时提供丰富的会议管理能力以满足不同应用场景";
    lab1.textColor = [UIColor blackColor];
    lab1.font = [UIFont boldSystemFontOfSize:14];
    lab1.highlightedTextColor = [UIColor whiteColor];
    lab1.backgroundColor = [UIColor clearColor];
    lab1.tag = 1001;
    [self.view addSubview:lab1];
    lab1.lineBreakMode = UILineBreakModeWordWrap;
    lab1.numberOfLines = 0;
    [lab1 release];
    
    UILabel* lab2;
    lab2 = [[UILabel alloc] initWithFrame:CGRectMake(20, 360, 280, 60)];
    lab2.textColor = [UIColor blueColor];
    lab2.highlightedTextColor = [UIColor whiteColor];
    lab2.text = @"本Demo演示一对多视频会议，即多方查看一方视频、可手动切换，语音为多方实时参与";
    lab2.font = [UIFont systemFontOfSize:14];
    lab2.backgroundColor = [UIColor clearColor];
    lab2.tag = 1001;
    lab2.lineBreakMode = UILineBreakModeWordWrap;
    lab2.numberOfLines = 0;
    [self.view addSubview:lab2];
    [lab2 release];
    
    UIButton* btn = [UIButton buttonWithType:(UIButtonTypeRoundedRect)];
    btn.frame = CGRectMake(200.f, 400, 90, 30);
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(goNext) forControlEvents:(UIControlEventTouchUpInside)];
}

-(void)goNext
{
    UISelectViewController* selectView = [[UISelectViewController alloc] initWithAccountList:self.modelEngineVoip.accountArray andSelectType:ESelectViewType_VideoConf];
    selectView.backView = self;
    [self.navigationController pushViewController:selectView animated:YES];
    [selectView release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end